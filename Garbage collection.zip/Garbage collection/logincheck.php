<?php
session_start();
?>
<?php
include "connection.php";
$username=$_POST['mailId'];
$password=$_POST['password'];
$query="select * from signUpDetails where EmailId='$username' && ConfirmPwd='$password'";
$data=mysqli_query($connection,$query);
$total=mysqli_num_rows($data);
if($total==0){
	
	header('location:register.html');
}
else
{
	header('location:home.html');
	
}
$_SESSION["email"]=$username;
$_SESSION["pwd"]=$password;
?>














